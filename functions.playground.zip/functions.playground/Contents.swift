import UIKit

var deckLength = 240
var deckWidth = 120
var area = deckLength * deckWidth

// function
func calculateArea(length: Int, width: Int) -> Int{
    return length * width
}





func sayHelloCollege() -> String {
    return "Welcome to my World"
}

//call functions
print(sayHelloCollege())
print(calculateArea(length: deckLength, width: deckWidth))

func greet(person: String) -> String{
    let greeting = "Welcome to my World, " + person + "!"
    return greeting
}

print(greet(person: "Lance"))

var bankAccBal = 300.99
var itemBuy = 599.97

func purchasedItem(currentBalance: inout Double, itemPrice: Double){
    if itemPrice <= currentBalance{
        currentBalance = currentBalance - itemPrice
        print("Purchased item for : $\(itemPrice)")
    }else {
        print("sorry funds not available")
    }
}

//call the function
purchasedItem(currentBalance: &bankAccBal, itemPrice: itemBuy)


















