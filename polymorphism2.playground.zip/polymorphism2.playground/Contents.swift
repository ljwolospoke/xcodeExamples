import UIKit

//wrong way of doing things
/*
class Rectangle {
    var area: Double
    func calculateArea(Length: Double, Width: Double){
        area = Length * Width
    }
}*/
//ect with triangle and squares and stuff

//right way of doing this

//polymorphism
class Shape {
    var area: Double?
    
    func calculateArea(valA: Double, valB: Double){
        
    }
}

//Triangle
class Triangle: Shape {
    override func calculateArea(valA: Double, valB: Double) {
        area = (valA * valB) / 2
    }
}

//rectangle
class Rectangle: Shape {
    override func calculateArea(valA: Double, valB: Double) {
        area = (valA * valB) / 2
    }
}
