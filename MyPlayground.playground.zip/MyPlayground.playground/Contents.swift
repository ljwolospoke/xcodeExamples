import UIKit

var str = "Hello, playground"
var amIAwesome = false
var scoreAHS = true
var gainALV = false

scoreAHS = !scoreAHS
var feelExcitedAboutSpring = true
feelExcitedAboutSpring = amIAwesome ? true : false

var checkingAccountBalance = 2
var dunkinDonutsCashier = checkingAccountBalance >= 5 ? " nooo my mons" : "sorry too broke"
