import UIKit

//step one
class Vechicle {
    var tires = 4
    var make: String?
    var model : String?
    var currentSpeed: Double = 0
    
    //step4
    init(){
        print("Parent Class")
    }
    //step2
    func drive(speedIncrease: Double){
        currentSpeed += speedIncrease * 2
    }
    
    //step 3
    func brake(){
        
    }
}

class SportsCar: Vechicle {
    override init() {
        super.init()
        print("Child Class") //output purposes
        make = "pontiac"
        model = "Trans Am"
    }

    override func drive(speedIncrease: Double){
        currentSpeed += speedIncrease * 8
    }

}
    let car = SportsCar()
