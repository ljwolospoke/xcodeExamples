import UIKit

var highScore = 44
var score = 43
var totalScore = highScore + score

var myMoney : Double = 12345678910112131415161718


var myNewMoney: Float = 3.79
var remainder = 14 % 5

var randomNumber = 12
if randomNumber  % 2 == 0 {
    print("Its Even")
} else {
    print("its odd")
}
