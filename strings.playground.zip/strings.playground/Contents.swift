import UIKit

var firstName = "Lance"
var lastName = "Woloszyn"
var suffix = " XV"

var fullName = firstName + " " + lastName
fullName.append(suffix)

var anime = "sword art online"
anime = anime.capitalized

var movie = "IAM NUMBER FOUR"
movie = movie.lowercased()






var statement = "Lance will ask another awesome question tofay, and something will not work for him."

if  statement.contains("lance") || statement.contains("QUESTION"){
    print("Sorry Students")
} else {
    print("Sorry the keywords were not found")
}

// REPLACE STATEMENT VALUES
statement.replacingOccurrences(of: "Lance", with: "Sammy")









