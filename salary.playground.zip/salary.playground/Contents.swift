import UIKit

var bigBen = 23200000.00 //0
var crosby = 8700000.00//1
var juju = 1144302.00//2
var mariska = 10800000.0//30
var jconner = 844572.00//4
var playersSalaries: [Double] = [bigBen,crosby,juju,mariska,jconner]


//the size of thge array
playersSalaries.count

//remove a person
playersSalaries.remove(at: 3)
playersSalaries.count

//create new array
var nbaPlayers = [String]()
print(nbaPlayers.count)
nbaPlayers.append("Lebron James")
nbaPlayers.append("Charles Barkley")
nbaPlayers.append("Michael Jordan")
nbaPlayers.append("Magic Johnson")
nbaPlayers.append("Larry Bird")
nbaPlayers.count
nbaPlayers.remove(at: 0)
nbaPlayers.count
